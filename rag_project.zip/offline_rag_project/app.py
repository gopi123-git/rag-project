import streamlit as st
from rag_core import process_pdfs, ask_question

st.title("📚 Offline Personal Research AI (RAG)")

uploaded_files = st.file_uploader(
    "Upload Research PDFs",
    type=["pdf"],
    accept_multiple_files=True
)

if st.button("Process Documents"):
    if uploaded_files:
        process_pdfs(uploaded_files)
        st.success("Documents processed and embeddings stored!")

query = st.text_input("Ask a research question")

if query:
    answer, sources = ask_question(query)

    st.subheader("Answer")
    st.write(answer)

    st.subheader("Sources")
    for s in sources:
        st.write(f"- {s}")
