import os
import faiss
import numpy as np

from langchain_community.document_loaders import PyPDFLoader
from langchain.text_splitter import RecursiveCharacterTextSplitter

from sentence_transformers import SentenceTransformer
from transformers import pipeline

VECTOR_DIR = "vectorstore"

# Embedding model
embed_model = SentenceTransformer("all-MiniLM-L6-v2")

# Local LLM
generator = pipeline(
    "text2text-generation",
    model="google/flan-t5-base",
    max_length=256
)

def process_pdfs(files):

    os.makedirs(VECTOR_DIR, exist_ok=True)

    documents = []
    sources = []

    for file in files:

        path = os.path.join(VECTOR_DIR, file.name)

        with open(path, "wb") as f:
            f.write(file.getbuffer())

        loader = PyPDFLoader(path)
        docs = loader.load()

        for d in docs:
            documents.append(d.page_content)
            sources.append(f"{file.name} (page {d.metadata['page']})")

    splitter = RecursiveCharacterTextSplitter(
        chunk_size=500,
        chunk_overlap=100
    )

    chunks = splitter.split_text("\n".join(documents))

    embeddings = embed_model.encode(chunks)

    dimension = embeddings.shape[1]

    index = faiss.IndexFlatL2(dimension)
    index.add(np.array(embeddings))

    faiss.write_index(index, f"{VECTOR_DIR}/index.faiss")

    np.save(f"{VECTOR_DIR}/chunks.npy", np.array(chunks))
    np.save(f"{VECTOR_DIR}/sources.npy", np.array(sources))


def ask_question(query):

    index = faiss.read_index(f"{VECTOR_DIR}/index.faiss")

    chunks = np.load(f"{VECTOR_DIR}/chunks.npy", allow_pickle=True)
    sources = np.load(f"{VECTOR_DIR}/sources.npy", allow_pickle=True)

    query_vector = embed_model.encode([query])

    k = 3

    distances, indices = index.search(np.array(query_vector), k)

    context = ""
    citations = []

    for i in indices[0]:
        context += chunks[i] + "\n"
        citations.append(sources[i])

    prompt = f"""
Use the following research context to answer the question.

Context:
{context}

Question:
{query}

Answer:
"""

    result = generator(prompt)[0]["generated_text"]

    return result, citations
