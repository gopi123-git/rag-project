# Offline Personal Research AI (RAG)

This project demonstrates Retrieval-Augmented Generation (RAG) running fully offline.

## Features
- Upload multiple research PDFs
- Document chunking
- SentenceTransformer embeddings
- FAISS vector database
- Semantic similarity search
- Local LLM (FLAN-T5) answer generation
- Citations from source PDFs

## Install
pip install -r requirements.txt

## Run
streamlit run app.py
